package com.example.real_new;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RealNewApplication {

	public static void main(String[] args) {
		SpringApplication.run(RealNewApplication.class, args);
	}

}
