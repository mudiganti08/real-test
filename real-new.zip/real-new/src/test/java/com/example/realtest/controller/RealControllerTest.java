package com.example.realtest.controller;

import com.example.realtest.entity.Movie;
import com.example.realtest.service.MovieService;
import com.fasterxml.jackson.databind.ObjectMapper;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.bean.override.mockito.MockitoBean; // ✅ Spring Boot 4.x
import org.springframework.test.web.servlet.MockMvc;

import java.util.List;
import java.util.Optional;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(RealController.class)
class RealControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockitoBean                        // ✅ replaces @MockBean in Spring Boot 4.x
    private MovieService movieService;

    @Autowired
    private ObjectMapper objectMapper;

    private Movie movie;

    @BeforeEach
    void setUp() {
        movie = new Movie();
        movie.setId(1L);
        movie.setTitle("Inception");
        movie.setGenere("Sci-Fi");
    }

    @Test
    void getAllMovies_returnsMovieList() throws Exception {
        when(movieService.findAll()).thenReturn(List.of(movie));

        mockMvc.perform(get("/movies"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.length()").value(1))
                .andExpect(jsonPath("$[0].id").value(1L))
                .andExpect(jsonPath("$[0].title").value("Inception"));

        verify(movieService, times(1)).findAll();
    }

    @Test
    void getAllMovies_returnsEmptyList_whenNoMoviesExist() throws Exception {
        when(movieService.findAll()).thenReturn(List.of());

        mockMvc.perform(get("/movies"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.length()").value(0));
    }

    @Test
    void getById_returnsMovie_whenFound() throws Exception {
        when(movieService.findById(1L)).thenReturn(Optional.of(movie));

        mockMvc.perform(get("/movies/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1L))
                .andExpect(jsonPath("$.title").value("Inception"));

        verify(movieService).findById(1L);
    }

    @Test
    void getById_returnsEmpty_whenNotFound() throws Exception {
        when(movieService.findById(99L)).thenReturn(Optional.empty());

        mockMvc.perform(get("/movies/99"))
                .andExpect(status().isOk());

        verify(movieService).findById(99L);
    }

    @Test
    void deleteMovie_returns200_whenDeleted() throws Exception {
        doNothing().when(movieService).deleteMovie(1L);

        mockMvc.perform(delete("/movies/1"))
                .andExpect(status().isOk());

        verify(movieService).deleteMovie(1L);
    }

    @Test
    void deleteMovie_callsServiceWithCorrectId() throws Exception {
        doNothing().when(movieService).deleteMovie(5L);

        mockMvc.perform(delete("/movies/5"))
                .andExpect(status().isOk());

        verify(movieService, times(1)).deleteMovie(5L);
    }

    @Test
    void createMovie_returnsCreatedMovie() throws Exception {
        when(movieService.createMovie(any(Movie.class))).thenReturn(movie);

        mockMvc.perform(post("/movies/create")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(movie)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1L))
                .andExpect(jsonPath("$.title").value("Inception"));

        verify(movieService).createMovie(any(Movie.class));
    }

    @Test
    void updateMovie_returnsUpdatedMovie_whenFound() throws Exception {
        Movie updated = new Movie();
        updated.setId(1L);
        updated.setTitle("Inception Updated");
        updated.setGenere("Thriller");

        when(movieService.updateMovie(eq(1L), any(Movie.class))).thenReturn(Optional.of(updated));

        mockMvc.perform(put("/movies/1")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(updated)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.title").value("Inception Updated"));

        verify(movieService).updateMovie(eq(1L), any(Movie.class));
    }

    @Test
    void updateMovie_returnsEmpty_whenMovieNotFound() throws Exception {
        when(movieService.updateMovie(eq(99L), any(Movie.class))).thenReturn(Optional.empty());

        mockMvc.perform(put("/movies/99")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(movie)))
                .andExpect(status().isOk());

        verify(movieService).updateMovie(eq(99L), any(Movie.class));
    }
}