package com.example.real_new;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RealNewApplicationTests {

	@Test
	void contextLoads() {
	}

}
