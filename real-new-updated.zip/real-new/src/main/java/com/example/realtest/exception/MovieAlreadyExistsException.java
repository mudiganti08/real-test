package com.example.realtest.exception;

public class MovieAlreadyExistsException extends RuntimeException {
    public MovieAlreadyExistsException(String title) {
        super("Movie already exists with title: " + title);
    }
}