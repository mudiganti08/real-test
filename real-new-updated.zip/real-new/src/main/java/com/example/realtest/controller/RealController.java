package com.example.realtest.controller;

import com.example.realtest.dto.MovieRequest;
import com.example.realtest.dto.MovieResponse;
import com.example.realtest.entity.Movie;
import com.example.realtest.service.MovieService;
import jakarta.annotation.*;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/movies")
@RequiredArgsConstructor
public class RealController {

    private final MovieService movieService;
    

    public RealController(MovieService movieService) {
		super();
		this.movieService = movieService;
	}

	// ✅ Get all
    @GetMapping
    public ResponseEntity<List<MovieResponse>> getAllMovies() {
        return ResponseEntity.ok(movieService.findAll());
    }

    // ✅ Get by ID — returns 404 if not found via exception handler
    @GetMapping("/{id}")
    public MovieResponse getById(@PathVariable Long id) {
        return movieService.findById(id);
    }

    // ✅ Create — returns 201
    @PostMapping("/create")
    public ResponseEntity<MovieResponse> create(@Validated @RequestBody MovieRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED).body(movieService.createMovie(request));
    }

    // ✅ Update
    @PutMapping("/{id}")
    public ResponseEntity<MovieResponse> updateMovie(@PathVariable Long id,
                                                     @Validated @RequestBody MovieRequest request) {
        return ResponseEntity.ok(movieService.updateMovie(id, request));
    }

    // ✅ Delete — returns 204 No Content
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteMovie(@PathVariable Long id) {
        movieService.deleteMovie(id);
        return ResponseEntity.noContent().build();
    }

    // ✅ Paging & Sorting — GET /movies/paged?page=0&size=5&sortBy=rating&direction=desc
    @GetMapping("/paged")
    public ResponseEntity<Page<MovieResponse>> getAllPaged(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "id") String sortBy,
            @RequestParam(defaultValue = "asc") String direction) {
        return ResponseEntity.ok(movieService.findAllPaged(page, size, sortBy, direction));
    }

    // ✅ By genre paged — GET /movies/genre/Action?page=0&size=5
    @GetMapping("/genre/{genere}")
    public ResponseEntity<Page<MovieResponse>> getByGenre(
            @PathVariable String genere,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {
        return ResponseEntity.ok(movieService.findByGenere(genere, page, size));
    }

    // ✅ By director paged
    @GetMapping("/director/{director}")
    public ResponseEntity<Page<MovieResponse>> getByDirector(
            @PathVariable String director,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {
        return ResponseEntity.ok(movieService.findByDirector(director, page, size));
    }

    // ✅ Search by title — GET /movies/search?title=inc
    @GetMapping("/search")
    public ResponseEntity<List<MovieResponse>> searchByTitle(@RequestParam String title) {
        return ResponseEntity.ok(movieService.searchByTitle(title));
    }

    // ✅ Top rated — GET /movies/top-rated?minRating=8.0
    @GetMapping("/top-rated")
    public ResponseEntity<List<MovieResponse>> getTopRated(
            @RequestParam(defaultValue = "7.0") Double minRating) {
        return ResponseEntity.ok(movieService.findTopRated(minRating));
    }

    // ✅ Between years — GET /movies/years?from=2000&to=2020
    @GetMapping("/years")
    public ResponseEntity<List<MovieResponse>> getByYearRange(
            @RequestParam int from,
            @RequestParam int to) {
        return ResponseEntity.ok(movieService.findMoviesBetweenYears(from, to));
    }

    // ✅ By rating — GET /movies/rating?min=8.5
    @GetMapping("/rating")
    public ResponseEntity<List<MovieResponse>> getByRating(
            @RequestParam Double min) {
        return ResponseEntity.ok(movieService.findByRatingAbove(min));
    }
}