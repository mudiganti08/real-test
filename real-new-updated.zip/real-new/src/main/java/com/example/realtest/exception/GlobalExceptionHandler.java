package com.example.realtest.exception;

import com.example.realtest.dto.ErrorResponse;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

@RestControllerAdvice
public class GlobalExceptionHandler {

    // ✅ Handle Movie not found
	@ExceptionHandler(MovieNotFoundException.class)
	public ResponseEntity<ErrorResponse> handleMovieNotFound(MovieNotFoundException ex) {

	    ErrorResponse response = new ErrorResponse();
	    response.setStatus(HttpStatus.NOT_FOUND.value());
	    response.setMessage(ex.getMessage());
	    response.setTimestamp(LocalDateTime.now());

	    return ResponseEntity
	            .status(HttpStatus.NOT_FOUND)
	            .body(response);
	}

    // ✅ Handle duplicate movie
	@ExceptionHandler(MovieAlreadyExistsException.class)
	public ResponseEntity<ErrorResponse> handleMovieAlreadyExists(MovieAlreadyExistsException ex) {

	    ErrorResponse response = new ErrorResponse();
	    response.setStatus(HttpStatus.CONFLICT.value());
	    response.setMessage(ex.getMessage());
	    response.setTimestamp(LocalDateTime.now());

	    return ResponseEntity
	            .status(HttpStatus.CONFLICT)
	            .body(response);
	}
 // ✅ Handle @Validated / @Valid failures
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<ErrorResponse> handleValidationErrors(MethodArgumentNotValidException ex) {

        Map<String, String> fieldErrors = new HashMap<String, String>();
        for (FieldError error : ex.getBindingResult().getFieldErrors()) {
            fieldErrors.put(error.getField(), error.getDefaultMessage());
        }

        ErrorResponse response = new ErrorResponse();
        response.setStatus(HttpStatus.BAD_REQUEST.value());
        response.setMessage("Validation failed");
        response.setTimestamp(LocalDateTime.now());
        response.setErrors(fieldErrors);

        return ResponseEntity
                .status(HttpStatus.BAD_REQUEST)
                .body(response);
    }

    // ✅ Handle all other exceptions
    @ExceptionHandler(Exception.class)
    public ResponseEntity<ErrorResponse> handleGenericException(Exception ex) {

        ErrorResponse response = new ErrorResponse();
        response.setStatus(HttpStatus.INTERNAL_SERVER_ERROR.value());
        response.setMessage("An unexpected error occurred");
        response.setTimestamp(LocalDateTime.now());
        response.setErrors(new HashMap<String, String>());  // ✅ Java 8 way, no Map.of()

        return ResponseEntity
                .status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body(response);
    }
}