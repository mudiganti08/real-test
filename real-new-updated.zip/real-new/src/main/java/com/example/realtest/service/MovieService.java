package com.example.realtest.service;

import com.example.realtest.dto.MovieRequest;
import com.example.realtest.dto.MovieResponse;
import org.springframework.data.domain.Page;

import java.util.List;

public interface MovieService {
    List<MovieResponse> findAll();
    MovieResponse findById(Long id);                          // ✅ throws exception if not found
    MovieResponse createMovie(MovieRequest request);
    MovieResponse updateMovie(Long id, MovieRequest request);
    void deleteMovie(Long id);

    // ✅ Paging & Sorting
    Page<MovieResponse> findAllPaged(int page, int size, String sortBy, String direction);
    Page<MovieResponse> findByGenere(String genere, int page, int size);
    Page<MovieResponse> findByDirector(String director, int page, int size);

    // ✅ Custom queries
    List<MovieResponse> findByRatingAbove(Double rating);
    List<MovieResponse> findMoviesBetweenYears(int from, int to);
    List<MovieResponse> searchByTitle(String title);
    List<MovieResponse> findTopRated(Double minRating);
}