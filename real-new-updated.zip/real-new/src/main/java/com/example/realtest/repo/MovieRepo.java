package com.example.realtest.repo;

import com.example.realtest.entity.Movie;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface MovieRepo extends JpaRepository<Movie, Long> {

    // ✅ Find by director
    List<Movie> findByDirector(String director);

    // ✅ Find by genre
    List<Movie> findByGenere(String genere);

    // ✅ Find by release year
    List<Movie> findByReleaseYear(Integer releaseYear);

    // ✅ Find by rating greater than or equal
    List<Movie> findByRatingGreaterThanEqual(Double rating);

    // ✅ Search by title containing (case-insensitive)
    List<Movie> findByTitleContainingIgnoreCase(String title);

    // ✅ Custom JPQL — movies between years
    @Query("SELECT m FROM Movie m WHERE m.releaseYear BETWEEN :from AND :to")
    List<Movie> findMoviesBetweenYears(@Param("from") int from, @Param("to") int to);

    // ✅ Custom JPQL — top rated movies
    @Query("SELECT m FROM Movie m WHERE m.rating >= :minRating ORDER BY m.rating DESC")
    List<Movie> findTopRatedMovies(@Param("minRating") Double minRating);

    // ✅ Paging support
    Page<Movie> findAll(Pageable pageable);

    Page<Movie> findByGenere(String genere, Pageable pageable);

    Page<Movie> findByDirector(String director, Pageable pageable);
}