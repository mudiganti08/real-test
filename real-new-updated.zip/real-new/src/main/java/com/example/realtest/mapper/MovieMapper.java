package com.example.realtest.mapper;

import com.example.realtest.dto.MovieRequest;
import com.example.realtest.dto.MovieResponse;
import com.example.realtest.entity.Movie;
import org.springframework.stereotype.Component;

@Component
public class MovieMapper {

    public Movie toEntity(MovieRequest request) {
        Movie movie = new Movie();
        movie.setTitle(request.getTitle());
        movie.setDirector(request.getDirector());
        movie.setGenere(request.getGenere());
        movie.setReleaseYear(request.getReleaseYear());
        movie.setRating(request.getRating());
        return movie;
    }

    public MovieResponse toResponse(Movie movie) {
        MovieResponse response = new MovieResponse();
        response.setId(movie.getId());
        response.setTitle(movie.getTitle());
        response.setDirector(movie.getDirector());
        response.setGenere(movie.getGenere());
        response.setReleaseYear(movie.getReleaseYear());
        response.setRating(movie.getRating());
        return response;
    }
}