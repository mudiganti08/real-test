package com.example.realtest.service.impl;

import com.example.realtest.dto.MovieRequest;
import com.example.realtest.dto.MovieResponse;
import com.example.realtest.entity.Movie;
import com.example.realtest.exception.MovieNotFoundException;
import com.example.realtest.mapper.MovieMapper;
import com.example.realtest.repo.MovieRepo;
import com.example.realtest.service.MovieService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class MovieServiceImpl implements MovieService {

    private final MovieRepo movieRepo;
    private final MovieMapper movieMapper;
    
    

    public MovieServiceImpl(MovieRepo movieRepo, MovieMapper movieMapper) {
		super();
		this.movieRepo = movieRepo;
		this.movieMapper = movieMapper;
	}

	@Override
    public List<MovieResponse> findAll() {
        return movieRepo.findAll()
                .stream()
                .map(movieMapper::toResponse)
                .toList();
    }

    @Override
    public MovieResponse findById(Long id) {
        Movie movie = movieRepo.findById(id)
                .orElseThrow(() -> new MovieNotFoundException(id)); // ✅ throws 404
        return movieMapper.toResponse(movie);
    }

    @Override
    public MovieResponse createMovie(MovieRequest request) {
        Movie movie = movieMapper.toEntity(request);
        return movieMapper.toResponse(movieRepo.save(movie));
    }

    @Override
    public MovieResponse updateMovie(Long id, MovieRequest request) {
        Movie existing = movieRepo.findById(id)
                .orElseThrow(() -> new MovieNotFoundException(id));
        existing.setTitle(request.getTitle());
        existing.setDirector(request.getDirector());
        existing.setGenere(request.getGenere());
        existing.setReleaseYear(request.getReleaseYear());
        existing.setRating(request.getRating());
        return movieMapper.toResponse(movieRepo.save(existing));
    }

    @Override
    public void deleteMovie(Long id) {
        if (!movieRepo.existsById(id)) {
            throw new MovieNotFoundException(id); // ✅ throws 404 instead of silent fail
        }
        movieRepo.deleteById(id);
    }

    @Override
    public Page<MovieResponse> findAllPaged(int page, int size, String sortBy, String direction) {
        Sort sort = direction.equalsIgnoreCase("desc")
                ? Sort.by(sortBy).descending()
                : Sort.by(sortBy).ascending();
        Pageable pageable = PageRequest.of(page, size, sort);
        return movieRepo.findAll(pageable).map(movieMapper::toResponse);
    }

    @Override
    public Page<MovieResponse> findByGenere(String genere, int page, int size) {
        Pageable pageable = PageRequest.of(page, size);
        return movieRepo.findByGenere(genere, pageable).map(movieMapper::toResponse);
    }

    @Override
    public Page<MovieResponse> findByDirector(String director, int page, int size) {
        Pageable pageable = PageRequest.of(page, size);
        return movieRepo.findByDirector(director, pageable).map(movieMapper::toResponse);
    }

    @Override
    public List<MovieResponse> findByRatingAbove(Double rating) {
        return movieRepo.findByRatingGreaterThanEqual(rating)
                .stream().map(movieMapper::toResponse).toList();
    }

    @Override
    public List<MovieResponse> findMoviesBetweenYears(int from, int to) {
        return movieRepo.findMoviesBetweenYears(from, to)
                .stream().map(movieMapper::toResponse).toList();
    }

    @Override
    public List<MovieResponse> searchByTitle(String title) {
        return movieRepo.findByTitleContainingIgnoreCase(title)
                .stream().map(movieMapper::toResponse).toList();
    }

    @Override
    public List<MovieResponse> findTopRated(Double minRating) {
        return movieRepo.findTopRatedMovies(minRating)
                .stream().map(movieMapper::toResponse).toList();
    }
}