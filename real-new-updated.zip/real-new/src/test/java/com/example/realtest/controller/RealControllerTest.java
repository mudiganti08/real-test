package com.example.realtest.controller;

import com.example.realtest.dto.MovieRequest;
import com.example.realtest.dto.MovieResponse;
import com.example.realtest.exception.MovieNotFoundException;
import com.example.realtest.service.MovieService;
import com.fasterxml.jackson.databind.ObjectMapper;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(RealController.class)
class RealControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockitoBean
    private MovieService movieService;

    @Autowired
    private ObjectMapper objectMapper;

    private MovieResponse movieResponse;   // ✅ Response DTO (what service returns)
    private MovieRequest movieRequest;     // ✅ Request DTO (what controller receives)

    @BeforeEach
    void setUp() {
        // ✅ MovieResponse — returned by service
        movieResponse = new MovieResponse();
        movieResponse.setId(1L);
        movieResponse.setTitle("Inception");
        movieResponse.setDirector("Nolan");
        movieResponse.setGenere("Sci-Fi");
        movieResponse.setReleaseYear(2010);
        movieResponse.setRating(8.8);

        // ✅ MovieRequest — sent in request body
        movieRequest = new MovieRequest();
        movieRequest.setTitle("Inception");
        movieRequest.setDirector("Nolan");
        movieRequest.setGenere("Sci-Fi");
        movieRequest.setReleaseYear(2010);
        movieRequest.setRating(8.8);
    }

    // ────────────────────────────────────────────────
    // GET /movies
    // ────────────────────────────────────────────────

    @Test
    void getAllMovies_returnsMovieList() throws Exception {
        when(movieService.findAll()).thenReturn(Arrays.asList(movieResponse));

        mockMvc.perform(get("/movies"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.length()").value(1))
                .andExpect(jsonPath("$[0].id").value(1L))
                .andExpect(jsonPath("$[0].title").value("Inception"));

        verify(movieService, times(1)).findAll();
    }

    @Test
    void getAllMovies_returnsEmptyList_whenNoMoviesExist() throws Exception {
        when(movieService.findAll()).thenReturn(Collections.emptyList());

        mockMvc.perform(get("/movies"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.length()").value(0));
    }

    // ────────────────────────────────────────────────
    // GET /movies/{id}
    // ────────────────────────────────────────────────

    @Test
    void getById_returnsMovie_whenFound() throws Exception {
        when(movieService.findById(1L)).thenReturn(movieResponse); // ✅ returns MovieResponse not Optional

        mockMvc.perform(get("/movies/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1L))
                .andExpect(jsonPath("$.title").value("Inception"));

        verify(movieService).findById(1L);
    }

    @Test
    void getById_returns404_whenNotFound() throws Exception {
        when(movieService.findById(99L)).thenThrow(new MovieNotFoundException(99L)); // ✅ throws exception → 404

        mockMvc.perform(get("/movies/99"))
                .andExpect(status().isNotFound());

        verify(movieService).findById(99L);
    }

    // ────────────────────────────────────────────────
    // DELETE /movies/{id}
    // ────────────────────────────────────────────────

    @Test
    void deleteMovie_returns204_whenDeleted() throws Exception {
        doNothing().when(movieService).deleteMovie(1L);

        mockMvc.perform(delete("/movies/1"))
                .andExpect(status().isNoContent()); // ✅ 204 not 200

        verify(movieService).deleteMovie(1L);
    }

    @Test
    void deleteMovie_returns404_whenNotFound() throws Exception {
        doThrow(new MovieNotFoundException(99L)).when(movieService).deleteMovie(99L); // ✅ throws 404

        mockMvc.perform(delete("/movies/99"))
                .andExpect(status().isNotFound());

        verify(movieService).deleteMovie(99L);
    }

    // ────────────────────────────────────────────────
    // POST /movies/create
    // ────────────────────────────────────────────────

    @Test
    void createMovie_returnsCreatedMovie() throws Exception {
        when(movieService.createMovie(any(MovieRequest.class))).thenReturn(movieResponse); // ✅ MovieRequest in, MovieResponse out

        mockMvc.perform(post("/movies/create")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(movieRequest))) // ✅ send MovieRequest
                .andExpect(status().isCreated()) // ✅ 201 not 200
                .andExpect(jsonPath("$.id").value(1L))
                .andExpect(jsonPath("$.title").value("Inception"));

        verify(movieService).createMovie(any(MovieRequest.class));
    }

    @Test
    void createMovie_returns400_whenBodyIsInvalid() throws Exception {
        MovieRequest invalid = new MovieRequest(); // ✅ empty request — all @NotBlank/@NotNull will fail

        mockMvc.perform(post("/movies/create")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(invalid)))
                .andExpect(status().isBadRequest()); // ✅ 400
    }

    // ────────────────────────────────────────────────
    // PUT /movies/{id}
    // ────────────────────────────────────────────────

    @Test
    void updateMovie_returnsUpdatedMovie_whenFound() throws Exception {
        MovieResponse updated = new MovieResponse();
        updated.setId(1L);
        updated.setTitle("Inception Updated");
        updated.setDirector("Nolan");
        updated.setGenere("Thriller");
        updated.setReleaseYear(2010);
        updated.setRating(9.0);

        when(movieService.updateMovie(eq(1L), any(MovieRequest.class))).thenReturn(updated); // ✅ MovieRequest in, MovieResponse out

        mockMvc.perform(put("/movies/1")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(movieRequest)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.title").value("Inception Updated"));

        verify(movieService).updateMovie(eq(1L), any(MovieRequest.class));
    }

    @Test
    void updateMovie_returns404_whenMovieNotFound() throws Exception {
        when(movieService.updateMovie(eq(99L), any(MovieRequest.class)))
                .thenThrow(new MovieNotFoundException(99L)); // ✅ throws exception → 404

        mockMvc.perform(put("/movies/99")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(movieRequest)))
                .andExpect(status().isNotFound());

        verify(movieService).updateMovie(eq(99L), any(MovieRequest.class));
    }
}