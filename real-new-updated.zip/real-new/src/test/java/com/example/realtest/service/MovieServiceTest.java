package com.example.realtest.service;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.example.realtest.dto.MovieRequest;
import com.example.realtest.dto.MovieResponse;
import com.example.realtest.entity.Movie;
import com.example.realtest.exception.MovieNotFoundException;
import com.example.realtest.mapper.MovieMapper;
import com.example.realtest.repo.MovieRepo;
import com.example.realtest.service.impl.MovieServiceImpl;

@ExtendWith(MockitoExtension.class)
public class MovieServiceTest {

    @Mock
    private MovieRepo movieRepo;

    @Mock
    private MovieMapper movieMapper;       // ✅ must mock mapper too

    @InjectMocks
    private MovieServiceImpl movieService; // ✅ Mockito injects both mocks above

    private Movie movie;
    private MovieResponse movieResponse;
    private MovieRequest movieRequest;

    @BeforeEach
    void setUp() {
        // ✅ Entity
        movie = new Movie();
        movie.setId(1L);
        movie.setTitle("Inception");
        movie.setDirector("Nolan");
        movie.setGenere("Sci-Fi");
        movie.setReleaseYear(2010);
        movie.setRating(8.8);

        // ✅ Response DTO
        movieResponse = new MovieResponse();
        movieResponse.setId(1L);
        movieResponse.setTitle("Inception");
        movieResponse.setDirector("Nolan");
        movieResponse.setGenere("Sci-Fi");
        movieResponse.setReleaseYear(2010);
        movieResponse.setRating(8.8);

        // ✅ Request DTO
        movieRequest = new MovieRequest();
        movieRequest.setTitle("Inception");
        movieRequest.setDirector("Nolan");
        movieRequest.setGenere("Sci-Fi");
        movieRequest.setReleaseYear(2010);
        movieRequest.setRating(8.8);
    }

    // ────────────────────────────────────────────────
    // findAll()
    // ────────────────────────────────────────────────

    @Test
    void shouldReturnAllMovies() {
        when(movieRepo.findAll()).thenReturn(Arrays.asList(movie));
        when(movieMapper.toResponse(movie)).thenReturn(movieResponse);

        List<MovieResponse> result = movieService.findAll();

        assertEquals(1, result.size());
        assertEquals("Inception", result.get(0).getTitle());
        verify(movieRepo, times(1)).findAll();
    }

    @Test
    void shouldReturnEmptyList_whenNoMovies() {
        when(movieRepo.findAll()).thenReturn(Collections.emptyList());

        List<MovieResponse> result = movieService.findAll();

        assertEquals(0, result.size());
        verify(movieRepo, times(1)).findAll();
    }

    // ────────────────────────────────────────────────
    // findById()
    // ────────────────────────────────────────────────

    @Test
    void shouldReturnMovieById() {
        when(movieRepo.findById(1L)).thenReturn(Optional.of(movie));
        when(movieMapper.toResponse(movie)).thenReturn(movieResponse); // ✅ mapper must be stubbed

        MovieResponse result = movieService.findById(1L);

        assertEquals("Inception", result.getTitle());
        assertEquals(1L, result.getId());
        verify(movieRepo).findById(1L);
    }

    @Test
    void shouldThrowException_whenMovieNotFound() {
        when(movieRepo.findById(99L)).thenReturn(Optional.empty());

        // ✅ service throws MovieNotFoundException instead of returning empty
        assertThrows(MovieNotFoundException.class, () -> movieService.findById(99L));
        verify(movieRepo).findById(99L);
    }

    // ────────────────────────────────────────────────
    // createMovie()
    // ────────────────────────────────────────────────

    @Test
    void shouldCreateMovie() {
        when(movieMapper.toEntity(movieRequest)).thenReturn(movie);
        when(movieRepo.save(movie)).thenReturn(movie);
        when(movieMapper.toResponse(movie)).thenReturn(movieResponse);

        MovieResponse result = movieService.createMovie(movieRequest);

        assertEquals("Inception", result.getTitle());
        verify(movieRepo).save(movie);
    }

    // ────────────────────────────────────────────────
    // updateMovie()
    // ────────────────────────────────────────────────

    @Test
    void shouldUpdateMovie_whenFound() {
        MovieRequest updateRequest = new MovieRequest();
        updateRequest.setTitle("Inception Updated");
        updateRequest.setDirector("Nolan");
        updateRequest.setGenere("Thriller");
        updateRequest.setReleaseYear(2010);
        updateRequest.setRating(9.0);

        MovieResponse updatedResponse = new MovieResponse();
        updatedResponse.setId(1L);
        updatedResponse.setTitle("Inception Updated");

        when(movieRepo.findById(1L)).thenReturn(Optional.of(movie));
        when(movieRepo.save(movie)).thenReturn(movie);
        when(movieMapper.toResponse(movie)).thenReturn(updatedResponse);

        MovieResponse result = movieService.updateMovie(1L, updateRequest);

        assertEquals("Inception Updated", result.getTitle());
        verify(movieRepo).findById(1L);
        verify(movieRepo).save(movie);
    }

    @Test
    void shouldThrowException_whenUpdatingNonExistentMovie() {
        when(movieRepo.findById(99L)).thenReturn(Optional.empty());

        assertThrows(MovieNotFoundException.class,
                () -> movieService.updateMovie(99L, movieRequest));

        verify(movieRepo).findById(99L);
        verify(movieRepo, never()).save(any()); // ✅ save should never be called
    }

    // ────────────────────────────────────────────────
    // deleteMovie()
    // ────────────────────────────────────────────────

    @Test
    void shouldDeleteMovie_whenFound() {
        when(movieRepo.existsById(1L)).thenReturn(true);
        doNothing().when(movieRepo).deleteById(1L);

        movieService.deleteMovie(1L);

        verify(movieRepo).existsById(1L);
        verify(movieRepo).deleteById(1L);
    }

    @Test
    void shouldThrowException_whenDeletingNonExistentMovie() {
        when(movieRepo.existsById(99L)).thenReturn(false);

        assertThrows(MovieNotFoundException.class,
                () -> movieService.deleteMovie(99L));

        verify(movieRepo).existsById(99L);
        verify(movieRepo, never()).deleteById(anyLong()); // ✅ deleteById should never be called
    }
}