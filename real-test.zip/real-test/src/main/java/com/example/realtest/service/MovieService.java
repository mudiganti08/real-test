package com.example.realtest.service;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.example.realtest.entity.Movie;


@Service
public interface MovieService{
	
	public List<Movie> findAll();
	public Optional<Movie> findById(Long id);
	public Movie createMovie(Movie movie);
	public Optional<Movie> updateMovie(Long id,Movie movie);
	public void deleteMovie(Long id);
	
}
