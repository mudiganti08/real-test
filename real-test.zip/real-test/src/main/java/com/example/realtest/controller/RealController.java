package com.example.realtest.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.realtest.entity.Movie;
import com.example.realtest.service.MovieService;

import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/movies")
public class RealController {
	
	private final MovieService movieService;
	
	public RealController(MovieService movieService) {
		this.movieService = movieService;
	}
	
	@GetMapping()
	public List<Movie> getAllMovies(){
		return movieService.findAll();
	}
	@GetMapping("/{id}")
	public Optional<Movie> getById(@PathVariable Long id) {
		return movieService.findById(id);
	}
	
	@DeleteMapping("/{id}")
	public void deleteMovie(@PathVariable Long id) {
		 movieService.deleteMovie(id);
	}
	@PostMapping("/create")
	public Movie create(@Validated @RequestBody Movie movie) {
		return movieService.createMovie(movie);
	}
	
	@PutMapping("/{id}")
	public Optional<Movie> updateMovie(@PathVariable Long id, @RequestBody Movie movie) {
		return movieService.updateMovie(id, movie);
	}
	

}
