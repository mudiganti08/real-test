package com.example.realtest.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.example.realtest.entity.Movie;
import com.example.realtest.repo.MovieRepo;
import com.example.realtest.service.MovieService;

import lombok.RequiredArgsConstructor;

@Service

public class MovieServiceImpl implements MovieService {
	
	private final MovieRepo movieRepo;
	
	
	
	public MovieServiceImpl(MovieRepo movieRepo) {
		super();
		this.movieRepo = movieRepo;
	}

	@Override
	public List<Movie> findAll() {
		// TODO Auto-generated method stub
		return movieRepo.findAll();
	}

	@Override
	public Optional<Movie> findById(Long id) {
		// TODO Auto-generated method stub
		return movieRepo.findById(id);
	}

	@Override
	public Movie createMovie(Movie movie) {
		// TODO Auto-generated method stub
		return movieRepo.save(movie);
	}

	@Override
	public Optional<Movie> updateMovie(Long id,Movie movie) {
		// TODO Auto-generated method stub
		 
		return movieRepo.findById(id)
				.map(exist -> {
					exist.setDirector(movie.getDirector());
					exist.setGenere(movie.getGenere());
					exist.setReleaseYear(movie.getReleaseYear());
					return movieRepo.save(exist);
					
				});
	}
		


	@Override
	public void deleteMovie(Long id) {
		movieRepo.deleteById(id);
		
	}

}
