package com.example.realtest.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.when;

import java.util.Optional;

import org.assertj.core.api.Assert;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.context.bean.override.mockito.MockitoBean;

import com.example.realtest.entity.Movie;
import com.example.realtest.repo.MovieRepo;
import com.example.realtest.service.impl.MovieServiceImpl;

@ExtendWith(MockitoExtension.class)
public class MovieServiceTest {

	@Mock
	MovieRepo movieRepo;

	@InjectMocks
	MovieServiceImpl movieService;

	 @Test
	    void shouldReturnMovieById(){

	        Movie movie = new Movie();
	        movie.setId(1L);
	        movie.setTitle("Inception");

	        when(movieRepo.findById(anyLong()))
	                .thenReturn(Optional.of(movie));

	        Optional<Movie> result = movieService.findById(1L);

	        assertEquals("Inception", result.get().getTitle());
	    }

}
